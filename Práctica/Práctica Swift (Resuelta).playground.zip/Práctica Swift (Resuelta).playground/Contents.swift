import Foundation

struct Client: Equatable, Hashable {
	let name: String
	let age: UInt8
	let heightInCentimeters: UInt8
}

struct Reservation: Equatable {
	let id: String
	let hotelName: String
	let clients: Set<Client>
	let daysInHotel: UInt8
	let price: Double
	let isBreakfastIncluded: Bool
}

enum ReservationError: Error {
	case foundReservationWithSameID
	case foundReservationForClient
	case reservationNotFound
}

class HotelReservationManager {

	private(set) var reservations: [Reservation] = []

	func addReservation(for clients: Set<Client>, daysInHotel: UInt8, isBreakfastIncluded: Bool) -> Result<Reservation, ReservationError> {

		for reservation in reservations {
			if reservation.clients.intersection(clients).count > 0 {
				return .failure(.foundReservationForClient)
			}
		}

		let id = UUID().uuidString
		if reservations.contains(where: { $0.id == id }) {
			return .failure(.foundReservationWithSameID)
		}

		let basePricePerClient: Double = 20
		let multiplierPriceForBreakfast: Double = isBreakfastIncluded ? 1.25 : 1
		let price = Double(clients.count) * basePricePerClient * Double(daysInHotel) * multiplierPriceForBreakfast
		let reservation = Reservation(
			id: id,
			hotelName: "Luchadores",
			clients: clients,
			daysInHotel: daysInHotel,
			price: price,
			isBreakfastIncluded: isBreakfastIncluded
		)
		self.reservations.append(reservation)
		return .success(reservation)
	}

	func cancelReservation(id: String) throws {
		if reservations.contains(where: { $0.id == id }) {
			reservations = reservations.filter { $0.id != id }
		} else {
			throw ReservationError.reservationNotFound
		}
	}
}

// tests

func testAddReservation() {
	let clients = Set([
		Client(name: "Goku", age: 41, heightInCentimeters: 175),
		Client(name: "Vegeta", age: 46, heightInCentimeters: 164)
	])
	let daysInHotel: UInt8 = 4
	let isBreakfastIncluded = false
	let hotelReservationManager = HotelReservationManager()
	let reservationResult = hotelReservationManager.addReservation(
		for: clients,
		daysInHotel: daysInHotel,
		isBreakfastIncluded: isBreakfastIncluded
	)
	switch reservationResult {
	case .success(let reservation):
		assert(reservation.clients == clients)
		assert(reservation.daysInHotel == daysInHotel)
		assert(reservation.isBreakfastIncluded == isBreakfastIncluded)
		assert(hotelReservationManager.reservations.contains(reservation))
		assert(hotelReservationManager.reservations.count == 1)
	case .failure:
		assertionFailure("no debe ocurrir")
	}

	let reservationForSameClientsResult = hotelReservationManager.addReservation(for: clients, daysInHotel: daysInHotel, isBreakfastIncluded: isBreakfastIncluded)
	guard case .failure(let error) = reservationForSameClientsResult, error == .foundReservationForClient else {
		assertionFailure("la reserva debía fallar pero no lo hizo")
		return
	}
}

func testCancelReservation() {
	let clients = Set([
		Client(name: "Goku", age: 41, heightInCentimeters: 175),
		Client(name: "Vegeta", age: 46, heightInCentimeters: 164)
	])
	let daysInHotel: UInt8 = 4
	let isBreakfastIncluded = false
	let hotelReservationManager = HotelReservationManager()
	let reservationResult = hotelReservationManager.addReservation(
		for: clients,
		daysInHotel: daysInHotel,
		isBreakfastIncluded: isBreakfastIncluded
	)
	switch reservationResult {
	case .success(let reservation):
		assert(hotelReservationManager.reservations.contains(reservation))
		assert(hotelReservationManager.reservations.count == 1)

		do {
			try hotelReservationManager.cancelReservation(id: reservation.id)
			assert(hotelReservationManager.reservations.isEmpty)
		} catch {
			assertionFailure("no puede ocurrir")
		}

		do {
			try hotelReservationManager.cancelReservation(id: reservation.id)
			assertionFailure("try debería fallar y irse al catch específico, ejecuta esta aserción sino")
		} catch ReservationError.reservationNotFound {
			assert(hotelReservationManager.reservations.isEmpty)
		} catch {
			assertionFailure("no debería de producir otro fallo distinto de reservationNotFound")
		}
	case .failure:
		assertionFailure("no puede ocurrir")
	}
}

func testReservationPrice() {
	let clients1 = Set([
		Client(name: "Goku", age: 41, heightInCentimeters: 175),
		Client(name: "Vegeta", age: 46, heightInCentimeters: 164)
	])
	let clients2 = Set([
		Client(name: "Piccolo", age: 41, heightInCentimeters: 175),
		Client(name: "Krillin", age: 46, heightInCentimeters: 164)
	])
	let daysInHotel: UInt8 = 4
	let isBreakfastIncluded = false
	let hotelReservationManager = HotelReservationManager()
	let reservationResult1 = hotelReservationManager.addReservation(
		for: clients1,
		daysInHotel: daysInHotel,
		isBreakfastIncluded: isBreakfastIncluded
	)
	let reservationResult2 = hotelReservationManager.addReservation(
		for: clients2,
		daysInHotel: daysInHotel,
		isBreakfastIncluded: isBreakfastIncluded
	)

	switch (reservationResult1, reservationResult2) {
	case (.success(let reservation1), .success(let reservation2)):
		assert(reservation1.price == reservation2.price)
		assert(hotelReservationManager.reservations.contains(reservation1))
		assert(hotelReservationManager.reservations.contains(reservation2))
		assert(hotelReservationManager.reservations.count == 2)
	default:
		assertionFailure("cannot happen!")
	}
}

//

testAddReservation()
testCancelReservation()
testReservationPrice()

print("¡todo correcto!")
