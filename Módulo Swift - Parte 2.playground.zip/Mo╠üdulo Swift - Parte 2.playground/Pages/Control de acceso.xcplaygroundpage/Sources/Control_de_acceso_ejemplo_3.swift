import Foundation

public class Something {
	fileprivate func something() {}
	private func nothing() {}
}

public class Other {
	public func other() {
		let something = Something()
		// podemos acceder a este método en este fichero
		// porque es `fileprivate`
		something.something()
		// si intentamos acceder a un método privado, obtendremos un error
		// ERROR: 'nothing' is inaccessible due to 'private' protection level
		//something.nothing()
	}
}
