import Foundation

// Dste fichero es como si estuviera en otro `módulo` (parecido a cuando creáramos unas bibliotecas).
// Debemos declarar las cosas como `public` para que sea accesible desde el módulo principal del playground.

public enum Color {
	case blue
	case red
}


// `internal` es el nivel de acceso por defecto
// en este caso es igual que ponga `internal` o que no ponga nada.
// Como estos `struct` son internal, no podré acceder a ellos desde
// el playground principal.
internal struct Person1 {}
struct Person2 {}
