import Foundation

// Dentro de un mismo módulo, podemos usar todo lo que definamos
// como `internal`.
public func displayPerson1() {
	let person1 = Person1()
	print(person1)
}

// Esta clase será accesible desde fuera y también se podrá
// heredar de esta clase y sobreescribir los métodos.
open class DisplayManager {

	// IMPORTANTE declarar el constructor como público, sino no
	// podremos instanciar el objeto desde fuera de este módulo...
	public init() {}

	public func powerOn() {}

	// cuidado, los métodos también pueden ser o no `open`
	// solo podremos sobreescribir aquellos que son `open`
	open func powerOff() {}

	// cuidado con olvidarnos de usar `public` en clases públicas,
	// ya que sino no será visible desde fuera
	func destroyDisplay() {}
}

// Esta clase será accesibles desde fuera pero NO podremos
// heredar de ella desde fuera ni sobreescribir sus métodos.
public class PrinterManager {
	public func print() {}
}
