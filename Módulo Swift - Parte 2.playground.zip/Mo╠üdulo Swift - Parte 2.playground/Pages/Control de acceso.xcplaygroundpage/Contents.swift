//: ### Control de acceso

import Foundation

//: `private`

class DataValidator {

	func isPasswordValid(_ password: String) -> Bool {
		let cleanUppercasedCapitalizedPass = makeUppercasedCapitalized(text: cleanPassword(password))
		return (6...18).contains(cleanUppercasedCapitalizedPass.count)
	}

	// private

	private func cleanPassword(_ password: String) -> String {
		password
			.trimmingCharacters(in: .whitespacesAndNewlines)
			.replacingOccurrences(of: ".", with: String())
	}

	private func makeUppercasedCapitalized(text: String) -> String {
		text.uppercased().capitalized
	}
}

let dataValidator = DataValidator()
// aquí solo podremos acceder al método isPasswordValid, que por defecto es `internal`
// el resto de métodos de esa clase son privados y son solo accesibles desde dentro
dataValidator.isPasswordValid("234dfsd")

class UserRepository {

	private let dataValidator: DataValidator

	init(dataValidator: DataValidator) {
		self.dataValidator = dataValidator
	}

	func saveIfCorect(password: String) {
		if dataValidator.isPasswordValid(password) {
			save(password)
		}
	}

	private func save(_ content: String) {
		// ...
	}
}

let userRepository = UserRepository(dataValidator: dataValidator)
// con userRepository NO podemos aceder a su `dataValidator` privado
// ni tampoco a su método privado `save`
userRepository.saveIfCorect(password: "12312d")

//: `public`

// Este enumerado está definido en un fichero dentro
// de la carpeta *Sources*; necesita estar definido como `public`
// para ser accesible desde aquí, igual pasaría al hacer bibliotecas.

Color.blue

// Estos `struct` al haberlos hemos definido con
// nivel de acceso `internal`, no son accesibles fuera de su módulo.
// ERROR: Cannot find 'Person1' in scope
//Person1()
// ERROR: Cannot find 'Person1' in scope
//Person2()

// esta función está definida en el fichero Sources/Control_de_acceso_ejemplo_2
// y hace un print de `Person1`, demostrando así que dentro de un mismo módulo
// podemos usar todo lo que sea `internal` pero fuera de este tan solo los que sean públicos (u `open`)
displayPerson1()

//: `open`

// `DisplayManager` es una clase `open` definida en el fichero
// Sources/Control_de_acces_ejemplo_2.
// Contiene algún método `public` y tan solo `powerOff` es `open`,
// con lo que podemos heredar de esta clase y sobreescribir aquellos métodos o propiedades
// marcados como `open`.
DisplayManager()

class MyDisplayManager: DisplayManager {
	override func powerOff() {
		print("powering off...")
	}
}

// Dentro de un mismo módulo, las clases por defecto
// son heredables.
class MyOtherDisplayManager: MyDisplayManager {
}
// Si quisiéramos que NO sean heredables, simplemente la
// marcamos con `final`
final class MyOtherOtherDisplayManager: MyDisplayManager {
}
// ERROR: Inheritance from a final class 'MyOtherOtherDisplayManager'
//class MyForbiddenDisplayManager: MyOtherOtherDisplayManager {}

//: `fileprivate`

// Tenemos un ejemplo en el fichero `Sources/Control_de_acceso_ejemplo_3`
// donde vemos que tan solo podemos acceder a los elementos marcados
// con `fileprivate` dentro del propio fichero donde se definen.

//: [Anterior ](@previous)
//: [ Siguiente](@next)
