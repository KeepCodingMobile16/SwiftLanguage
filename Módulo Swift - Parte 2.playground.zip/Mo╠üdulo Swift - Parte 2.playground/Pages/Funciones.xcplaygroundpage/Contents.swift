//: ### Funciones

//: 1. Sin parámetros de entrada ni de salida.
func myFunction() {
	print("something")
}
myFunction()

//: 2. Con un parámetro de entrada, sin devolver valor.
func myFunction2(parameter1: String) {
	print(parameter1)
}
myFunction2(parameter1: "something")

//: 3. Acepta un parámetro en el que se omite su nombre en la llamada a la función, sin devolver valor.
func myFunction3(_ parameter1: Int)  {
	print(parameter1)
}
myFunction3(10)

//: 4. Acepta un parámetro con alias, sin devolver valor.
func myFunction4(parameter2 p2: Int) {
	print(p2)
}
myFunction4(parameter2: 10)

//: 5. No acepta parámetros de entrada, devuelve un valor entero.
func myFunction5() -> Int {
	return 10
}
myFunction5()

//: 6. No acepta parámetros de entrada, devuelve un valor entero sin return (no hace falta cuando es solo una línea).
func myFunction53() -> Int {
	10
}
myFunction53()

//: 7. No acepta parámetros de entrada, devuelve una tupla 'anónima'.
func myFunction51() -> (Int, String) {
	return (10, "something")
}
myFunction51()

//: 8. No acepta parámetros de entrada, devuelve una tupla con nombres de parámetros.
func myFunction52() -> (age: Int, name: String) {
	return (123, "Dani")
}
myFunction52()

//: 9. Acepta un parámetro de entrada y produce una salida.
func myFunction5(someValue: String) -> Int {
	return Int(someValue) ?? 0
}
myFunction5(someValue: "10")

//: 10. Acepta 2 parámetros de entrada y produce una salida.
func myFunction6(parameter1: Int, parameter2: Int) -> Int {
	return parameter1 + parameter2
}
myFunction6(parameter1: 10, parameter2: 30)

//: 11. Acepta 2 parámetros de entrada y produce una salida. En el primer parámetro omitimos su etiqueta y el segundo parámetro tiene un alias/etiqueta.
func myFunction7(_ parameter1: Int, parameter2 p2: Int) -> Int {
	return parameter1 + p2
}
myFunction7(10, parameter2: 30)

//: [Anterior ](@previous)
//: [ Siguiente](@next)
