//: ### Código genérico (`generics`)

/*: Usamos los genéricos para poder aceptar distintos tipos de valores.
 Para representar que queremos usar un tipo genérico
 simplemente usarmos la sintaxis: <T>, donde T es el nombre
 del tipo genérico.
 */

// En Swift, además, se pueden especificar una serie de
// `constraints`/normas que esos tipos deben sguir.
// En este caso solo quiero aceptar valores genéricos
// que implementen el protocolor `Equatable`.
func isEqual<T: Equatable>(_ value1: T, _ value2: T) -> Bool {
	// una vez dentro de la función solo podremos llamar a métodos
	// y propiedades que nos permita el tipo, en este caso
	// el protocolo solo cuenta con un único método:
	// static func == (lhs: Self, rhs: Self) -> Bool
	return value1 == value2
}
// He aquí la potencia de los genéricos, nos permiten
// pasar diveros tipos de datos como parámetros con una única
// función en vez de crear varias para un mismo propósito.
isEqual(1, 3)
isEqual(1.5, 3.6)
isEqual("test", "asdfas")
// ERROR: Conflicting arguments to generic parameter 'T' ('Int' vs. 'String')
//isEqual("test", 23)

//: Ejemplos con estructuras

// Este es un ejemplo aplicado a una estructura.
struct OrderedSet<T: Hashable> {
	private var array: [T] = []
	private var set: Set<T> = []
	// ...
	mutating func add(_ value: T) {
		array.append(value)
		set.insert(value)
	}
}

// Otro ejemplo. Realmente podemos llamar como queramos al
// tipo genérico, en este caso `Element`
struct Stack<Element> {

	private var items: [Element] = []

	mutating func push(_ item: Element) {
		items.append(item)
	}

	@discardableResult
	mutating func pop() -> Element {
		return items.removeLast()
	}
}

//: Otros ejemplos de tipos genéricos

// Un ejemplo muy interesante de uso de los genéricos es también
// especificar una clase o un protocolo en lugar del tipo final real.
class MyParentClass {
	func test() {
		print("1")
	}
}

final class MyChildClass: MyParentClass {
	override func test() {
		print("2")
	}
}

func test(something: MyParentClass) {
	something.test()
}
test(something: MyChildClass())

// en lugar de usar <T> es posible también usar `any` seguido
// de un protocolo cuando no nos interesa conocer realmente
// el tipo del objeto sino solo un valor que implemente ese
// protocolo y que nos sirva para hacer alguna llamada a alguna
// propiedad o método
func hashOfValueAsString(_ value: any Hashable) -> String {
	String(value.hashValue)
}
hashOfValueAsString(12)
hashOfValueAsString("test")
hashOfValueAsString([2,23,3])

//: [Anterior ](@previous)
