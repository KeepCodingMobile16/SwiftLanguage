import Foundation

class MyClass {
	init() {
		print("inicializando")
	}
	deinit {
		print("deinicializando")
	}
}
var reference1: MyClass? = MyClass()
var reference2 = reference1
reference1 = nil
// Si comentamos la siguiente línea, "inicializando" no se mostrará por consola
reference2 = nil // "deinicializando" se mostrará just tras esta línea, porque ya no hay nadie con una instancia válida de MyClass
print("otra cosa")

//: Dependencias cíclicas fuertes (*strong reference cycles*)
class Person {
	let name: String
	var apartment: Apartment?

	init(name: String) {
		self.name = name
	}

	deinit {
		print("Person2 named: \(name) is being deinitialized")
	}
}

class Apartment {

	let address: String
	var tenant: Person? // inquilino

	init(address: String) {
		self.address = address
	}

	deinit {
		print("Apartment \(address) is being deinitialized")
	}
}

var goku: Person? = Person(name: "Goku")
var apartment1: Apartment? = Apartment(address: "Calle de la piruleta, 123")

goku?.apartment = apartment1
apartment1?.tenant = goku

goku = nil
apartment1 = nil

// como podéis ver, no se ha ejecutado ningún print de los deinit, esto es porque hemos creado la siguiente dependencia
// Person <-> Apartment
// Person tiene una referencia FUERTE hacia Apartment por la variable "apartment"
// Apartment tiene una referencia FUERTE hacia Person por la variable "tenant"
// para evitar que esto ocurra, en este tipo de casos podemos usar "weak"

class Person2 {
	let name: String
	var apartment: Apartment2?

	init(name: String) {
		self.name = name
	}

	deinit {
		print("Person2 named: \(name) is being deinitialized")
	}
}

class Apartment2 {

	let address: String
	weak var tenant: Person2? // inquilino

	init(address: String) {
		self.address = address
	}

	deinit {
		print("Apartment2 \(address) is being deinitialized")
	}
}

var goku2: Person2? = Person2(name: "Goku")
var apartment2: Apartment2? = Apartment2(address: "Calle de la piruleta, 123")

goku2?.apartment = apartment2
apartment2?.tenant = goku2

goku2 = nil
apartment2 = nil

// ahora podemos ver que sí se han deinicializado correctamente ambas clases
// ¿por qué?
// porque ahora aunque la relación es similar, al poner weak en la variable "tenant",
// en cuanto intentamos liberar apartment2, ahora sí se puede liberar goku2
// Es importante saber que si NO asignamos nil a "apartment2", entonces la instancia
// quedará viva dentro de "goku2?.apartment" y apartment2 no se deinicializará.

//: [Anterior ](@previous)
//: [ Siguiente](@next)
