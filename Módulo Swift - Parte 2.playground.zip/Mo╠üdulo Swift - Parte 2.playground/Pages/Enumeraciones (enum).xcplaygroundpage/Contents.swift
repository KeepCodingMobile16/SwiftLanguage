//: ### Enumeraciones (enum)

// Atentos:
// - Normalmente no se le pone "s" a los nombres de enumerados, se suele poner en singular.
// - Los `case` suelen ir en minúculas.
// Esto son solo estilos de programación,
// no hay problema realmente en llamarlos como deseemos,
// pero siempre en importante ser consistentes en nuestro código.
enum DragonBallCharacter {
	case goku
	case bulma
	case krilin
}
let character: DragonBallCharacter = DragonBallCharacter.krilin
let character2 = DragonBallCharacter.bulma
// En Swift podemos omitir el nombre del enumerado siempre y cuando
// Swift tenga claro el tipo exacto.
let character3: DragonBallCharacter = .goku
// por defecto se pueden comparar los enumerados sin problemas
character == character3
character == .krilin

/*: Los enumerados pueden tener un valor de un mismo tipo asociado.
 Esto se conoce como `Raw Values`. El `RawValue` de este enumerado
 es de tipo `String`, por lo que cada case tiene asociado un valor
 de tipo `String`, accesible con la propiedad `rawValue` (este valor debe ser único en todo el enumerado).
 */

// El valor de esta propiedad suele ser simplemente el nombre del `case` en caso
// de ser de tipo `String` aunque si queremos podemos asignarle el valor que queramos.
enum Color: String {
	case blue
	case green
	case gray = "custom name here"
}
let color = Color.blue
color.rawValue

// En los enumerados con `RawValue` Int, cada caso tiene un
// valor entero por defecto, empiezan en 0.
// Si ponemos un número personalizado, los `case` que vengan después (más abajo)
// tendrán un incremento en 1 de este valor.
enum Direction: Int {
	case north
	case south
	case east = 10
	case west
}
Direction.north.rawValue
Direction.east.rawValue
Direction.west.rawValue

// Es ideal usar `switch` para los enumerados.
// Fijaos que no hay caso por defecto (default), ya que Swift sabe
// que hemos puesto todos los valores del enumerado.
let direction = Direction.north
switch direction {
case .north:
	break
case .south:
	break
case .east:
	break
case .west:
	break
}

// también podemos usar los `if` de las siguientes maneras para compara enumerados
if direction == .north {
	//...
}
if case .north = direction {
	// ...
}

//: Es muy útil implementar el protocolo `CaseIterable`. Este nos permite obtener un listado de todos los casos del enumerado.
enum DragonBall: CaseIterable {
	case oneStar
	case twoStar
	case threeStar
	case fourStar
	case fiveStar
	case sixStar
	case sevenStar
}
DragonBall.oneStar
DragonBall.allCases

//: Es posible tener valores asociados solo a algunos casos del enumerado. De hecho si hacemos esto ya no puede tener `RawValue` nuestro enum.

// Los valores asociados pueden tener o no un nombre.
enum Smartphone {
	case android(model: String)
	case iOS(String)
}

let smartPhone: Smartphone = .iOS("something")
let smartPhone2: Smartphone = .iOS("something")

// Así se hace un switch para enumerados con valores asociados.
switch smartPhone {
case .android(model: let model):
	print(model)
case .iOS(let model):
	print(model)
}

// Comparar enumerados con valores asociados es algo más complicado,
// una forma es haciendo un `switch` de la tupla de ambos elementos a comparar.
switch (smartPhone, smartPhone2) {
case (.android(model: let model1), .android(model: let model2)):
	print(model1 == model2)
case (.iOS(let model1), .iOS(let model2)):
	print(model1 == model2)
default:
	print(false)
}

// Para usar un `if` con un `case` con valores asociados podemos hacer lo siguiente.
if case .android(model: let model) = smartPhone {
	print(model)
}
if case .android(model: let model) = smartPhone, model == "X" {
	print(model)
}

//: [Anterior ](@previous)
//: [ Siguiente](@next)
