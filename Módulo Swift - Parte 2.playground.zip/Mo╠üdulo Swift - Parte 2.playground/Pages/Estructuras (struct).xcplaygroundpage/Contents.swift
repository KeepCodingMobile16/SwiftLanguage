//: ### `struct`

/*: Por defecto los `struct` generan un constructor.
 Además, es muy sencillo hacer que implementen protocolos como `Equatable` y `Hashable`.
 */
struct Person: Equatable, Hashable {

	let name: String
	var age: Int
	private(set) var readOnlyProperty = 234

	// esto son propiedades estáticas, es decir:
	// - son accesibles desde cualquier lugar con Person.someStaticValue
	// - no están por tanto asociadas a ninguna instancia
	static let someStaticValue = 100
	static var someStaticVariable: String = "hola"

	func tellMyName() -> String {
		"My name is \(self.name)"
	}

	mutating func increaseAgeByOne() {
		self.age += 1
	}
}

let daniel = Person(name: "Daniel", age: 123)
daniel.name
daniel.readOnlyProperty
// error de compilación, esta variable no se puede cambiar desde fuera de Person
//daniel.readOnlyProperty = 900
Person.someStaticValue
Person.someStaticVariable = "asdf"

var goku = Person(name: "Goku", age: 41)
// **IMPORTANTE**: necesita ser `var` para cambiar su valor
goku.increaseAgeByOne()

goku == daniel
daniel.hashValue
String(describing: daniel)

/*: Por defecto un struct o una clase no se pueden comparar con `==` a no ser
 que implementen el protocolo `Equatable`.
 */
struct Test {
	let aaa: String
}
let test1 = Test(aaa: "d")
let test2 = Test(aaa: "d")
// error de compilación
//test1 == test2

/*: Aunque Swift cree un constructor (*internal*) por defecto, podemos igualmente añadir los constructores que necesitemos, aunque
	hay que tener en cuenta que en cuanto añadimos nuestros constructores,
	Swift "elimina" el constructor que teníamos por defecto con todos los parámetros.
 */

enum Color {
	case red
	case blue
}

struct House {

	let color: Color
	let doorsCount: Int

	init(color: Color = .red, doorsCount: Int) {
		self.color = color
		self.doorsCount = doorsCount
	}

	init() {
		self.color = .red
		self.doorsCount = 20
	}
}

House(color: .blue, doorsCount: 10)
House(doorsCount: 10)
House()

//: Los struct son *value-type*, es decir, se copian.

struct ThingStruct {
	var value: Int
}

let thing0 = ThingStruct(value: 0)
// ¿podré modificar `value`?
// no, necesito hacer que `thing0` sea un `var`, necesito que sea mutable.
// [IMPORTANTE] Pensad que: en cuanto de alguna forma se pueda modificar
// una propiedad tipo `struct` de un `struct, entonces la instancia
// debe ser una variable (`var`).

// El error que suelta Swift:
// Cannot assign to property: 'thing0' is a 'let' constant
// Change 'let' to 'var' to make it mutable
//thing0.value = 23

var thing1 = ThingStruct(value: 2)
var thing2 = thing1

thing1.value = 10
thing1.value
// qué valor tendrá `thing2.value`?
thing2.value
thing2.value = 29
// qué valor tendrá `thing1.value`?
thing1.value

// Con estos ejemplos demostramos que los valores de tipo `struct`
// siempre se copian tal cual, sin hacer referencia al valor del que
// se copian.

//: [Anterior ](@previous)
//: [ Siguiente](@next)
