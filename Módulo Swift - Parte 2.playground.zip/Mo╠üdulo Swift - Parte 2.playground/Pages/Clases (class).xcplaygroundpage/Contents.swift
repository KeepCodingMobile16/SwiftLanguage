//: ### Clases (`class`)

class Person: Equatable, Hashable, CustomStringConvertible {

	let name: String
	var age: Int

	init(name: String, age: Int) {
		self.name = name
		self.age = age
	}

	func tellMyName() -> String {
		"My name is \(self.name)"
	}

	// fijaos que ya no necesitamos `mutating` con métodos que cambien valores
	func increaseAgeByOne() {
		self.age += 1
	}

	// Equatable
	static func ==(lhs: Person, rhs: Person) -> Bool {
		guard lhs.name == rhs.name else { return false }
		guard lhs.age == rhs.age else { return false }
		return true
	}

	// Hashable
	func hash(into hasher: inout Hasher) {
		hasher.combine(self.name)
		hasher.combine(self.age)
	}

	// CustomStringConvertible
	var description: String {
		return "Person(name: \(self.name), age: \(self.age))"
	}
}

let daniel = Person(name: "Daniel", age: 123)
let goku = Person(name: "Goku", age: 41)
daniel.name

// **IMPORTANTE**: con las clases NO necesitamos usar `var` para cambiar valores internos
goku.increaseAgeByOne()

goku == daniel
daniel.hashValue
String(describing: daniel)

//: Podemos comparar si dos instancias se refieren a la misma instancia con `===`
class MyClass {}
let myClass1 = MyClass()
let myClass2 = MyClass()
myClass1 === myClass2
let myClass3 = myClass2
myClass3 === myClass2

//: Las clases son `reference-type`, es decir, los valores se referencian.

class ThingClass: CustomStringConvertible {
	var value: Int
	init(value: Int) {
		self.value = value
	}
	var description: String {
		"ThingClass(value: \(self.value)"
	}
}

let thing0 = ThingClass(value: 0)
// ¿podré modificar el valor de `value`?
// sí, porque `ThingClass` es una clase
thing0.value = 38

let thing1 = ThingClass(value: 20)
let thing2 = thing1

thing1.value = 90
thing1.value
thing2.value

// `thing2.value` es lo mismo que `thing1.value`
// ¿por qué?
// simplemente porque `thing2` es una referencia hacia `thing1`

//: Vamos a "complicar" un poco la cosa, vamos a mezclar `reference-type` y `value-type`.

struct ThingStruct {
	var value: Int
}

class Something: CustomStringConvertible {
	var thingClass: ThingClass
	var thingStruct: ThingStruct

	init(thingClass: ThingClass, thingStruct: ThingStruct) {
		self.thingClass = thingClass
		self.thingStruct = thingStruct
	}

	var description: String {
		"Something(thingClass: \(self.thingClass), thingStruct: \(self.thingStruct))"
	}
}

let something0 = Something(
	thingClass: ThingClass(value: 0),
	thingStruct: ThingStruct(value: 0)
)
something0.thingClass.value = 10
something0.thingStruct.value = 20

var something1 = Something(
	thingClass: ThingClass(value: 1),
	thingStruct: ThingStruct(value: 1)
)
var something2 = something1
something1.thingClass.value = 10
something1.thingStruct.value = 20
var something3 = something2
something1
something2
something3

// no cambia realmente nada con respecto al ejemplo anterior
// `something2` es una referencia de `something1` y siempre tendrá
// sus mismos valores; ocurre igual con `something3`, es solo una referencia

//: Volvamos a darle una vuelta a esto pero usando un `struct`.

struct SomethingStruct {
	var thingClass: ThingClass
	var thingStruct: ThingStruct
}

let something0Struct = SomethingStruct(
	thingClass: ThingClass(value: 0),
	thingStruct: ThingStruct(value: 0)
)
// puedo cambiar el valor de la clase sin problemas
something0Struct.thingClass.value = 10
// pero, como dijimos antes, cuando el valor es de tipo `struct`
// y estoy dentro de un `struct`, entonces ya no me deja cambiar su valor
// a no ser que `something0Struct` sea una variable (`var`).
//something0Struct.thingStruct.value = 20

var something1Struct = SomethingStruct(
	thingClass: ThingClass(value: 1),
	thingStruct: ThingStruct(value: 1)
)
var something2Struct = something1Struct
something1Struct.thingClass.value = 10
something1Struct.thingStruct.value = 20
var something3Struct = something1Struct
something1Struct
something2Struct
something3Struct

// MUCHO CUIDADO AQUÍ
// `something2Struct` es una copia de `something1Struct`
// por lo que todas sus propiedades `struct` se copian tal cual
// sin referenciar a nadie.
// PERO, `something1Struct.thingClass` es una instancia de una clase,
// entonces, al copiarse esta a `something2Struct` ocurre lo mismo
// que ocurría antes con las clases, simplemente `something2Struct.thinClass`
// es una referencia de `something1Struct.thingClass`.

//: [Anterior ](@previous)
//: [ Siguiente](@next)
