import Foundation

var name = "Daniel"
name = "Test"

var name2: String = "Daniel"

var age = 10
type(of: age)

var age1: UInt8 = 16
UInt8.min
UInt8.max

Int8.min
Int8.max

pow(2, 8)

var height = 120.0
var height1: Double = 120
var height2 = 120.45

let numbers = [1,2,3,4]
numbers.count
numbers.isEmpty
//numbers.append(10)

var numbers2 = [1,2,3,4]
numbers2.append(232)

Date()
//let calendar = Calendar.current
//calendar.date(byAdding: .day, value: 2, to: Date())

URL(string: "https://www.google.com")
URL(filePath: "/Users/Daniel/mifichero.txt")

func countCharacters(text: String) -> Int {
	return text.count
}

print(countCharacters(text: "asdfads"))

func add(number1: Double, number2: Double) -> Double {
	let result = number1 + number2
	return result
}

add(number1: 1.5, number2: 2.6)

func add2(_ number1: Double, _ number2: Double, otherNumber number3: Double) -> Double {
	let result = number1 + number2 + number3
	return result
}

add2(1.5, 2.6, otherNumber: 3)

let myAge: Int = 90
if myAge == 80 {
	print(80)
} else if myAge == 70 {
	print(70)
} else {
	print("ni 80 ni 70", myAge)
}

print(1,2,3, separator: "-")

// par: even
// impar: odd
func isEven(number: Int) -> Bool {

//	if number < 0 {
//		return false
//	}
	guard number >= 0 else {
		return false
	}

	if number % 2 == 0 {
		return true
	} else {
		return false
	}
}

let aNumber = 10
if aNumber == 5 {
	// ...
} else if aNumber == 10 {
	// ...
} else if aNumber == 20 {
	// ...
}

switch aNumber {
case 5:
	print("es 5")
case 10:
	print("es 10")
case 20:
	print("es 20")
default:
	print("otro")
}

// for-in

for i in [1,2,3,4] {
	i
}

let years = 1990...2023

for year in years {
	print(year)
}

for i in 0..<10 {
	print(i)
}
// stride
print("-------------")
var otherNumber = 0
while otherNumber == 0 {
	let randomNumber = (0...3).randomElement()!
	otherNumber = randomNumber
	print(randomNumber)
}
print("-------------")
otherNumber = 0
repeat {
	let randomNumber = (0...3).randomElement()!
	otherNumber = randomNumber
	print(randomNumber)
} while otherNumber == 0

let heightInMeters = 1.77
if heightInMeters == 1.77 {
	print("1.77")
}

var heightInMeters2 = 1.77
for _ in 0..<7 {
	heightInMeters2 -= 0.001
	print(heightInMeters2)

	if heightInMeters2 == 1.769 {
		print("esto -> 1.769")
	}

	if heightInMeters2 >= 1.769 && heightInMeters2 < 1.76909 {
		print("esto sí es -> 1.769")
	}

	if (1.769..<1.7691).contains(heightInMeters2) {
		print("esto sí es__ -> 1.769")
	}
}

let value: Decimal = 1.77
print(value - 0.001)

var characterName: String? = "test"
characterName = nil
characterName = "asdfas"

print(String(describing: characterName?.count))

characterName = nil

print(characterName?.count ?? 0)

characterName = "hola"

print(characterName!.count)

if characterName != nil {

}
if let characterName {
	characterName.count
}
if let otherCharacterName = characterName {
	otherCharacterName.count
}

assert(characterName == "hola")
//assert(characterName == "Hola", "el valor no es Hola")

if characterName == "Hola" {
	print("Hola")
} else {
	assertionFailure("no es hola")
}
