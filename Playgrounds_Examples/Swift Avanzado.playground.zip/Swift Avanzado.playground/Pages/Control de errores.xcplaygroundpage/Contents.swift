import Foundation

enum ValidationError: Error {
	case empty
	case tooLarge
}

func validate(text: String) throws {
	if text.isEmpty {
		throw ValidationError.empty
	} else if text.count > 20 {
		throw ValidationError.tooLarge
	}
}

func test() {

}

do {
	try validate(text: "")
	test()
	print("no hay error")
} catch let error {
	print(error)
}

do {
	try validate(text: "asdfasdfasdfasdfasdf asdfasdfasdfasdfads")
	print("no hay error")
} catch let error {
	print(error)

	let validationError = error as? ValidationError
	switch validationError {
	case .empty:
		print("ValidationError.empty")
	case .tooLarge:
		print("ValidationError.tooLarge")
	case nil:
		print("nil")
	}
}

do {
	try validate(text: "asdfasdfasdfasdfasdf asdfasdfasdfasdfads")
	print("no hay error")
} catch ValidationError.empty {
	print("ValidationError.empty")
} catch ValidationError.tooLarge {
	print("ValidationError.tooLarge")
} catch let error {
	print(error)
}

do {
	try validate(text: "Test")
	print("test->no hay error")
} catch let error {
	print(error)
}

print( try? validate(text: "") )
print( try? validate(text: "Test") )
print( try! validate(text: "Test") )


//

// Result

func validatedId(id: String) -> Result<String, ValidationError> {
	let cleanId = id.trimmingCharacters(in: .whitespacesAndNewlines)
	let cleanIdUppercased = cleanId.uppercased()

	if cleanIdUppercased.isEmpty {
		return Result.failure(ValidationError.empty)
	} else if cleanIdUppercased.count > 20 {
		return .failure(.tooLarge)
	}

	return .success(cleanIdUppercased)
}

validatedId(id: " 22222222j")

//
print("------------")

enum AgeValidationError: LocalizedError {
//	case lessThan18(age: Int)
	case lessThan18
	case tooOld

	var errorDescription: String? {
		switch self {
		case .lessThan18:
			return "AgeValidationError.lessThan18: the age is less than 18."
		case .tooOld:
			return "AgeValidationError.tooOld: the person is too old"
		}
	}
}

class DataValidator {

	func isAgeValid(age: Int) -> Bool {
		return (18...100).contains(age)
	}

	func validateAge(age: Int) throws {
		if age < 18 {
			throw AgeValidationError.lessThan18
		} else if age > 100 {
			throw AgeValidationError.tooOld
		}
	}

	func validatedId(id: String) -> String? {
		let cleanId = id.trimmingCharacters(in: .whitespacesAndNewlines)
		let cleanIdUppercased = cleanId.uppercased()

		if cleanIdUppercased.isEmpty {
			return nil
		} else if cleanIdUppercased.count > 20 {
			return nil
		}

		return cleanIdUppercased
	}
}

let dataValidator = DataValidator()
dataValidator.isAgeValid(age: 10)

do {
	try dataValidator.validateAge(age: 10)
} catch {
	print(error.localizedDescription)
}

//

print("----------")

class DataValidatorTests {

	func testIsAgeValid() {
		let dataValidator = DataValidator()
		assert(dataValidator.isAgeValid(age: 20))
		assert(dataValidator.isAgeValid(age: 28))
		assert(dataValidator.isAgeValid(age: 40))
		assert(dataValidator.isAgeValid(age: 100))
		assert(dataValidator.isAgeValid(age: 10) == false)
		assert(dataValidator.isAgeValid(age: 17) == false)
		assert(dataValidator.isAgeValid(age: 18))
		assert(dataValidator.isAgeValid(age: -10) == false)
	}

	func testValidateAge() {
		do {
			let dataValidator = DataValidator()
			try dataValidator.validateAge(age: 10)
			assertionFailure("si se ejecuta esta línea, entonces no entra en el catch")
		} catch {
			let validationError = error as? AgeValidationError
			assert(validationError != nil)
			assert(validationError == AgeValidationError.lessThan18)
		}

		do {
			let dataValidator = DataValidator()
			try dataValidator.validateAge(age: 20)
			print("aquí, la edad está validada, y ejecutamos esta línea sin problemas")
		} catch {
			assertionFailure("si se ejecuta esta línea, entonces entra en el catch")
		}
	}

	func testValidatedId() {
		let dataValidator = DataValidator()
		let validatedId = dataValidator.validatedId(id: " 22222222j")
		assert(validatedId == "22222222J", "el dni no parece estar bien")
		assertEquals(validatedId, "22222222J")

		let validatedId2 = dataValidator.validatedId(id: "")
		assert(validatedId2 == nil)
	}
}

let dataValidatorTests = DataValidatorTests()
dataValidatorTests.testIsAgeValid()
dataValidatorTests.testValidateAge()
dataValidatorTests.testValidatedId()

//

// esto sería una forma de implementar un assert personalizado (parecido al de XCTest)
func assertEquals<T: Equatable>(_ value1: T, _ value2: T) {
	if value1 != value2 {
		fatalError("\(value1) != \(value2)")
	}
}
