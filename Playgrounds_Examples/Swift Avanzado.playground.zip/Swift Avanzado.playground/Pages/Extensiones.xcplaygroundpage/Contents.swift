import Foundation

enum Color {
	case red
	case green
	case blue

	func printDescription() {
		print(self)
	}
}

extension Color {
	func isRed() -> Bool {
		return self == .red
	}
	var isRed2: Bool {
		return self == .red
	}
}

Color.red.isRed()
Color.blue.isRed2
//
struct Person {
	let name: String
}
extension Person {
	var reversedName: String {
		return String(self.name.reversed())
	}

	// ERROR: Extensions must not contain stored properties
//	var age: Int = 190
}
var daniel = Person(name: "Daniel")
daniel.name
daniel.reversedName

//

let name: String = "Daniel"
name.isEmpty

var otherName: String = " "
otherName.isEmpty

// isBlank

extension String {
	var isBlank: Bool {
		if isEmpty {
			return true
		}
		if self == " " {
			return true
		}
		return false
	}

	var isBlank2: Bool {
		let cleanString = self.trimmingCharacters(in: .whitespacesAndNewlines)
		return cleanString.isEmpty
	}
}

otherName.isBlank
otherName.isBlank2

//

let numbers1 = [1,2,3]
let numbers2 = [1,2,3]
numbers1 == numbers2

struct Mac: Equatable {
	let model: String
}
let mac1 = Mac(model: "1")
let mac2 = Mac(model: "2")
mac1 == mac2

let macs = [Mac(model: "1"), Mac(model: "2")]
let macs2 = [Mac(model: "1"), Mac(model: "2")]
// esto funciona gracias a: extension Array where Element : Equatable
macs == macs2
