class Example {

	var name = "Pepe"
	let name2 = "Pepe"

	func getName() -> String {
		return "Pepe"
	}

	// propiedad computada
	var myName: String {
		return "Pepe"
	}

	var myName2: String {
		get {
			return "Pepe"
		}
		set {
			print("quiero cambiar el valor de myName2")
			self.name = newValue
		}
	}
}

let example = Example()

example.name
example.name = "hola"

example.name2

example.getName()

example.myName
example.myName2
example.myName2 = "algo"

// error:
//example.myName = "asdf"

let numbers = [1,2,3]
numbers.isEmpty

//

enum Color {
	case red
	case green
	case blue
}
class Example2 {
	var color: Color = .red {
		willSet {
			print(color, "antes de cambiar el valor", newValue)
		}
		didSet {
			print(oldValue, "propiedad cambiada", color)
		}
	}
}
let example2 = Example2()
example2.color = .green
example2.color = .red

//

print("------------------------")

func addValues(_ number1: Int, _ number2: Int) -> Int {
	print("addValues se ha ejecutado")
	return number1 + number2
}

func addValues2(_ number1: Int, _ number2: Int) -> Int {
	print("addValues2 se ha ejecutado")
	return number1 + number2
}

class Example3 {

	var valueA = addValues(1, 2)

	lazy var valueB = addValues2(1, 2)

}

let example3 = Example3()
//example3.valueA
//example3.valueB

//

struct Circle {

	var radius: Double = 0.5

	var diameter: Double {
		get {
			return radius * 2
		}
		set {
			// newValue -> diámetro, diámetro = radio * 2
			self.radius = newValue / 2
		}
	}
}
var circle = Circle()
circle.diameter
circle.diameter = 10
circle.diameter
