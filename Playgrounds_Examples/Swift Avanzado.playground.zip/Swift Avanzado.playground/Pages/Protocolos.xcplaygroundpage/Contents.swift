
protocol CanFly {
	var hasWings: Bool { get }
	var canSing: Bool { get set }
	func fly()
}

struct Bird: CanFly {

	let hasWings: Bool = true

	var canSing: Bool

	init(canSing: Bool) {
		self.canSing = canSing
	}

	func fly() {
		print("I'm flying")
	}
}

var bird1 = Bird(canSing: true)
bird1.fly()
bird1.hasWings
bird1.canSing = false

struct Superhero: CanFly {

	let hasWings: Bool = false

	var canSing: Bool = false

	func fly() {
		print("I'm flying, I'm a superhero")
	}
}
let superman = Superhero()
superman.hasWings
superman.fly()

func example1Bird(bird: Bird) {
	bird.canSing
	bird.fly()
}
func example1Superhero(superhero: Superhero) {
	superhero.canSing
	superhero.fly()
}

func example1(canFlyValue: CanFly) {
	canFlyValue.canSing
	canFlyValue.fly()
}

func example2(canFlyValue: any CanFly) {
	canFlyValue.canSing
	canFlyValue.fly()
}

example1(canFlyValue: bird1)
example1(canFlyValue: superman)
