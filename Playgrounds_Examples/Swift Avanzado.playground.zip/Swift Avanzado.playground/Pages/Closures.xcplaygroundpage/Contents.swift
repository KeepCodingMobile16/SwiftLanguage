// Event Driven Development

// funciones que aceptan otras funciones como parámetro

func add() {
	print(1 + 2)
}

class Button {

	private var action: (() -> Void)?

	init() {}

	func setOnButtonClick(action: @escaping () -> Void) {
		self.action = action
	}

	func click() {
		self.action?()
	}
}

let button = Button()
button.setOnButtonClick(action: add)

func printHello() {
	print("hello")
}
let myFunction = printHello
button.setOnButtonClick(action: printHello)


// función anónima
// closure
// lambda
button.setOnButtonClick {
	print("hello")
}

//

class MyView {
	var button = Button()
	private let id = 123

	func viewDidLoad() {
		button.setOnButtonClick {
			print(self.id)
		}
	}
}

// subirImagen(imagen) // 10s
// print("Imagen subida")

// subirImagen(imagen) {
//     print("imagen subida")
// }

var myFunction2: (Int, Double) -> String = { parameter1, other in
	print(parameter1, other)
	return "asdf"
}

myFunction2(20, 2.3)
