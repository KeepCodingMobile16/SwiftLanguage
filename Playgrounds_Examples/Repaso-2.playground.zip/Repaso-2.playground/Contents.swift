import Foundation

// blue, green, red
// small, medium, large

enum Color {
	case blue
	case green
	case red
}

Color.blue
Color.green
Color.green == Color.green

enum Size {
	case small
	case medium
	case large
}

func applyStyle(color: Color, size: Size) {
	if color == Color.green {
		//
	}
	switch size {
	case .small:
		print("small")
	case .medium:
		print("medium")
	case .large:
		print("large")
	}
}
applyStyle(color: Color.blue, size: Size.large)
applyStyle(color: .blue, size: .large)

let calendar = Calendar.current
calendar.date(byAdding: Calendar.Component.day, value: 0, to: Date())
calendar.date(byAdding: .day, value: 0, to: Date())

enum Size2: Int {
	case small
	case large
	case extraLarge = 10
}
Size2.small.rawValue
Size2.large.rawValue
Size2.extraLarge.rawValue

//

// Persona
// brazos
// piernas
// nombre

var person1Name = "Daniel"
var person1Arms = 2
var person1Legs = 2

struct Person {
	let name: String
	let arms: UInt
	let legs: UInt
}

Person(name: "Daniel", arms: 2, legs: 2)
Person(name: "Pepe", arms: 4, legs: 4)

struct Person2: Equatable {
	let name: String
	let legs: UInt

	init(name: String, legs: UInt = 2) {
		self.name = name
		self.legs = legs
	}
}
Person2(name: "Daniel")
Person2(name: "Daniel", legs: 4)

let daniel = Person2(name: "Daniel")
let daniel2 = daniel
daniel == daniel2

struct House {
	var windows: Int = 4

	func printWindows() {
		print("\(numberOfWindows()): \(self.windows)")
		print("\(numberOfWindows()): \(windows)")
	}

	mutating func removeWindow() {
		guard self.windows > 0 else { return }
		self.windows -= 1
	}

	private func numberOfWindows() -> String {
		return "number of windows"
	}
}
var house1 = House(windows: 4)
var house2 = house1
house1.windows = 2
house2.windows
house2.printWindows()

var house3 = House(windows: 3)
house3.printWindows()
house3.removeWindow()

print(house3)

//

class Person3: Equatable, CustomStringConvertible {

	let name: String
	let arms: UInt
	let legs: UInt

	init(name: String, arms: UInt, legs: UInt) {
		self.name = name
		self.arms = arms
		self.legs = legs
	}

	static func == (lhs: Person3, rhs: Person3) -> Bool {
		return lhs.name == rhs.name && lhs.arms == rhs.arms && lhs.legs == lhs.legs
	}

	var description: String {
		return "Person3(name: \(self.name), arms: \(self.arms), legs: \(legs))"
	}
}

print(Person3(name: "a", arms: 0, legs: 0))

let person3 = Person3(name: "a", arms: 0, legs: 0)
let person4 = person3
person3 == person4

class Car {
	var tyres: Int = 0
}
let car1 = Car()
car1.tyres = 90
print(car1.tyres)

let car2 = car1
car2.tyres = 100
print("car1", car1.tyres)
print("car2", car2.tyres)

//

class Animal: Equatable {
	var legs: Int = 4

	func printLegs() {
		print("I have \(legs) legs")
	}

	static func == (lhs: Animal, rhs: Animal) -> Bool {
		return lhs.legs == rhs.legs
	}
}

class Dog: Animal {
	var vaccinations: Int = 0
	var name: String = ""
}
let dog1 = Dog()
dog1.legs
dog1.printLegs()
dog1.name = "a"
let dog2 = Dog()
dog2.name = "b"
dog1 == dog2

let animal1 = Animal()
animal1.legs
animal1.printLegs()
