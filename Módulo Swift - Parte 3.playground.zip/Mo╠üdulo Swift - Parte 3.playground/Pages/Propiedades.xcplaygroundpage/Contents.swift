//: ### Propiedades

//: Propiedades calculadas (*computed properties*)
var aValue: Double {
	return 23.45
}
// también
var aValue2: Double {
	get {
		return 23.45
	}
}
// Podemos ańadir también un setter con `set`.
// En ese ejemplo tendríamos una propiedad privada `radius` pero
// lo que se ve desde fuera es solo diameter, que usa por debajo `radius`.
struct Circle {
	private var radius: Double = 30

	var diameter: Double {
		get { radius * 2 }
		set { radius = newValue / 2 }
	}
}
let circle = Circle()
circle.diameter

//: Observadores de propiedad

var something: Int = 0 {
	willSet {
		print("will set", something, newValue)
	}
	didSet {
		print("did set", oldValue, something)
	}
}
something = 20

//: `lazy` var

class Something {
	lazy var value: Int = factorial(10) // con variables lazy, podemos usar métodos aquí
	var value2: Int = factorial2(10)    // con variables normales, no, solo quizá en el constructor o haciéndolo de otra forma

	private func factorial(_ n: Int) -> Int {
		print("called")
		if n <= 1 {
			return 1
		} else {
			return n * factorial(n - 1)
		}
	}
}
private func factorial2(_ n: Int) -> Int {
	   print("called2")
	   if n <= 1 {
		   return 1
	   } else {
		   return n * factorial2(n - 1)
	   }
   }

let smt = Something()
// en este punto, si vemos la consola veremos solamente
// prints de "called2", porque `value2` se ha inicializado
// pero `value` todavía no

// solo cuando específicamente usemos la propiedad entonces se inicializará
//smt.value

//: [Anterior ](@previous)
//: [ Siguiente](@next)
