//: ### Extensiones

//: Extender tipo propio

struct Person {
	let name: String
}

// con las extensiones podemos añadir nuevas funcionalidades
// fuera de la definición del tipo; es decir, el tipo puede estar definido
// en un fichero y nosotros podemos añadir funcionalidades en otro fichero distinto
extension Person {
	var reversedName: String {
		String(self.name.reversed())
	}
	func uppercasedName() -> String {
		self.name.uppercased()
	}
}

//: Extender tipos de Swift

import Foundation

extension String {
	var isBlank: Bool {
		return self.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
	}
}

" ".isBlank
"asdf".isBlank

//: Extensiones específicas

// Los tipos de Swift utilizan también extensiones para ofrecer
// ciertas funcionalidades a ciertos tipos de datos.
// Por ejemplo, podemos crear un Array de cualquier tipo (struct Array<Element>), pero
// no todos los tipos son comparables, sino solo los que implementen
// `Equatable`, por lo que un Array no puede ser siempre `Equatable`.
// Esto lo resuelve Swift con la extensión siguiente:
// extension Array : Equatable where Element : Equatable { ... }
// y podemos ver un ejemplo aquí.
var array = Array([1,23]) // los arrays se pueden escribir así con `Array`
var array2 = [1,23]       // o directamente con solo los corchetes
array == array2
// con tipos que no son Equatable no se pueden comparar los arrays
struct Something {}
var array3 = [Something()]
var array4 = [Something()]
// Error: Operator function '==' requires that 'Something' conform to 'Equatable'
//array3 == array4

//: [Anterior ](@previous)
//: [ Siguiente](@next)
