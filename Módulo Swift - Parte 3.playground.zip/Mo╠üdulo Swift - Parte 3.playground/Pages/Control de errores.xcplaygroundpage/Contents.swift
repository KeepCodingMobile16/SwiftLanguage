//: ### Control de errores

import Foundation

//: Definición de errores

enum ValidationError: Error {
	case empty
	case tooLarge
}

//: Uso de los errores con el tipo `Result`

// Result es un tipo que usa dos valores genéricos
// el primero es el valor que devuelve (o Void/() si no se devuelve nada)
// y el segundo un tipo de error.

func validate(text: String) -> Result<String, ValidationError> {
	if text.isEmpty {
		return .failure(.empty)
	}
	if text.count > 10 {
		return .failure(.tooLarge)
	}
	return .success(text)
}

let validationResult = validate(text: "aa")
switch validationResult {
case .success(let validatedText):
	print("success", validatedText)
case .failure(let validationError):
	print(validationError)
}

//: Uso de los errores con `throw`

func validate1(text: String) throws {
	if text.isEmpty {
		throw ValidationError.empty
	}
	if text.count > 10 {
		throw ValidationError.tooLarge
	}
}

// `do` en vez de `try`
do { // `try` se utiliza para llamar a código que pueda lanzar errores
	try validate1(text: "https://example.com")
	// si validate1 no lanza errores, entonces la siguiente línea se ejecuta
	print("is valid")
} catch { // o: } catch let error {
	// aquí tenemos disponible una variable `error`
	print(error)
}


// podemos poner también `catch let error`
do {
	try validate1(text: "https://example.com")
	print("is valid")
} catch let error {
	print(error)
}

// podemos capturar también errores específicos
do {
	try validate1(text: "https://example.com")
	print("is valid")
} catch ValidationError.tooLarge {
	print("too large")
} catch let error {
	print(error)
}

//: [Anterior ](@previous)
