//: ### Closures

func add(a: Int, b: Int) -> Int {
	return a + b
}
func subtract(a: Int, b: Int) -> Int {
	return a - b
}
func doOperation(_ operation: (Int, Int) -> Int, a: Int, b: Int) -> Int {
	return operation(a, b)
}
doOperation(add, a: 1, b: 2)
doOperation(subtract, a: 1, b: 2)

// En vez de usar funciones ya definidas como parámetros,
// podemos especificar esa función sin predefinirla, esto
// se conoce como función anónima, lambda o closure.
// La sintaxis es la siguiente: { <parámetros> in <código> }
doOperation({ a, b in a * b }, a: 1, b: 2)
doOperation(
	{ a, b in
		return a * b
	},
	a: 1,
	b: 2
)
// podemos usar a veces algunos operadores en vez de una función,
// en este caso el operador "*"
doOperation(*, a: 1, b: 2)

// Ejemplo de función que acepta una función sin parámetros de entrada.
func something(_ block: () -> Void) {
	block()
}

// en ese caso al no tener parámetros no usamos `<parámetros> in``
something({ print("something") })

// cuando un closure es el último parámetro de una función podemos omitir los paréntesis
something { print("something2") }

// es recomendable partir en varias líneas la llamada para que quede más legible
something {
	print("something2")
	print("something2")
	print("something2")
}

// ejemplo de una función que acepta varios parámetros y entre
// ellos acepta una función que, en este caso, devuelve un valor
func foo(bar: Int, aa: Double, block: () -> Int) {
}

// formas válidas de llamar a esta función
foo(bar: 1, aa: 2.3, block: { 3 })
foo(bar: 1, aa: 2.3, block: { return 3 })
foo(bar: 1, aa: 2.3) { 3 }
foo(bar: 1, aa: 2.3) { return 3 }
foo(bar: 1, aa: 2.3) {
	return 3
}

//: [Anterior ](@previous)
//: [ Siguiente](@next)
