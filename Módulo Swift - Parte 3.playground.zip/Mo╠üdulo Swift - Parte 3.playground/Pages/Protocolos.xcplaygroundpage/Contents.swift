//: ### Protocolos

protocol CanFly {
	// al definir propiedades debemos especificar si queremos
	// que se puedan leer (get) o leer y modificar (get set)
	var hasWings: Bool { get }
	var canSing: Bool { get set }
	func fly()

	// Los protolos no pueden contener métodos definidos, pero
	// sí podemos saltarnos estra restricción usando extensiones :)
	// ERROR: Protocol methods must not have bodies
//	func jump() {
//		print("I'm jumping!")
//	}
	// podemos también definir solo la cabecera de la función `func jump()` y luego usar extensiones
}
extension CanFly {
	func jump() {
		print("I'm jumping!")
	}
}

struct Bird: CanFly {

	var hasWings: Bool { true }

	var canSing: Bool = false

	func fly() {
		print("I am flying :)")
	}
}

var myBird = Bird()
myBird.hasWings
myBird.canSing = true
myBird.fly()
myBird.jump()

struct Superman: CanFly {

	var hasWings: Bool { false }

	var canSing: Bool = false

	func fly() {
		print("supermaaaan")
	}
}

let superman = Superman()

// lo bueno de los protocolos es no tener que especificar el tipo
// exacto que queremos, simplemente podemos indicar el nombre del
// protocolo, de esta forma estamos usando un código más genérico

let somethingThatFlies: CanFly = Superman()
somethingThatFlies.fly()
let somethingThatFlies2: CanFly = Bird()
somethingThatFlies2.fly()

// podemos usarlo en funciones también

func iBelieveIcanFly(_ value: CanFly) {
	value.fly()
}
iBelieveIcanFly(Bird())
iBelieveIcanFly(Superman())

// es recomendado usar "any <Tipo>", en el futuro quizá será obligatoria
// esa sintaxis: https://www.hackingwithswift.com/swift/5.6/existential-any

// así que mejor de esta forma
func iBelieveIcanFly2(_ value: any CanFly) {
	value.fly()
}
iBelieveIcanFly2(Bird())
iBelieveIcanFly2(Superman())

//: [Anterior ](@previous)
//: [ Siguiente](@next)
