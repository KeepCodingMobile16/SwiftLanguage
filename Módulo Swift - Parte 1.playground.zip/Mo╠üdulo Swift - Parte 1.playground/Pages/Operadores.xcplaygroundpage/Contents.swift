//: ### Operadores

var age = 10
var degreesCelsius = -10
var name = "Daniel"
var heightOfBuilding: Double = 23_423 // o 23423. "_" es un separador opcional que podemos usar
var isTall = false
var isShort: Bool = false
var isEmpty = name.isEmpty
var string: String? = "nullable string"
let heightInMeters: Double = 9.1
let numbers = [1, 2, 3, 4, 5]

//: - Operadores unarios: +, -, !

-degreesCelsius
-30
-age
+30
!isTall
// Force unwrapping: forzar un valor opcional a que te devuelve el valor o crashee
string!

//: - Operador de asignación: =

isShort = true
name = "something"
//heightInMeters = 2 // error de compilación, es una constante

//: - Operadores aritméticos: +, -, *, /, %

age + degreesCelsius
degreesCelsius -= 10
name + "Illescas"
heightOfBuilding * 10
10/10
11%2
// cuidado con las divisiones! division de números enteros siempre da un número entero truncado
15/4
15.0/4.0

//: - Operadores de comparación: ==, !=, >, <, >=, <=

isTall == true
heightOfBuilding > 1
heightOfBuilding < 10.5
heightOfBuilding >= 1
heightOfBuilding <= 10.5
name != "test"

//: - Operadores lógicos: NOT (!), AND (&&), OR (||)

!isTall
isTall && heightInMeters > 10
isTall || isEmpty

//: - Operadores de rango: ..., ..<

10...100
1..<10
...0
30...

//: - Operadores de asignación compuestos: +=, -=, *=, /=

var value = "a"
value += "b"
//value -= "b" // no es posible este operador con strings

var number = 10
number += 1
number -= 4
number *= 10
number /= 2

//: - Nil-Coalescing Operator: ??

string ?? "other"

let stringOrNil: String? = nil
stringOrNil ?? "default value!"

//: - Ternary conditional operator: (a ? b : c).

isTall ? 10 : 5

//: [Anterior ](@previous)
//: [ Siguiente](@next)
