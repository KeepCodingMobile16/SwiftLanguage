//: ### Declaración de variables y constantes

//: ![Partes de variable](swift-variable.png "https://kalkicode.com/images/swift/swift-variable.png")

//: - Variables
var age = 10
var degreesCelsius = -10
var name = "Daniel"
var heightOfBuilding: Double = 23_423 // o 23423. "_" es un separador opcional que podemos usar
var isTall = false
var isShort: Bool = false

age = 90
//age = 10.4 // error de compilación, age es de tipo entero
//age = "some text" // error de compilación, age es de tipo entero no de tipo String
degreesCelsius = -20
name = #"Other "quotes""# // Other "quotes". # se usa pra raw strings
heightOfBuilding = 200.45
isTall = true

age

//: - Constantes
let heightInMeters: Double = 9.1
let numbers = [1, 2, 3, 4, 5]

// heightInMeters = 29.1 // ¡error de compilación!, heightInMeters es una constante

//: los tipos básicos son siempre objetos, tienen propiedades y métodos
isShort.toggle()
heightInMeters.squareRoot()
degreesCelsius.magnitude
9.squareRoot()
"hello".count

heightInMeters.magnitude

//: Mostrar valores por consola

let name2 = "Daniel"
print(name2)
let age2 = 90
print(name2, age2)

//: Leer valores por consola (no funciona en playrounds!)

let userInput1: String? = readLine()
userInput1

//: [Anterior ](@previous)
//: [ Siguiente](@next)
