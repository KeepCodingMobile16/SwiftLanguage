//: ### Colecciones

//: **Array**: colección de valores que se puede repetir, son valores ordenados por inserción

var numbers: [Int] = [1,7,20,2]
numbers[0]
numbers[2]
numbers[0] = 10
numbers.remove(at: 0)
numbers.append(9)
numbers.append(contentsOf: [4,5])
numbers = [-1,-2] + numbers

let numbers2: Array<Int> = [1,345,45]
let numbers3 = Array<Double>([1,2,3,34])
let numbers4 = Array<Double>(repeating: 0, count: 10)

let matrix = [
	[0,3,4],
	[5,3,4],
	[0,7,8],
]

// tres en raya ;)
let ticTacToe = [
	[" "," ","O"],
	[" ","O","X"],
	["O"," ","X"],
]
type(of: ticTacToe)

[65,34,123,7,8,9].sorted()

// algunos métodos inmmutables (que no cambian el valor del array)
let myNumbers = [1,2,3,87]

myNumbers.sorted { lhs, rhs in
	lhs >= rhs
}
myNumbers.sorted(by: >)

myNumbers.first

myNumbers.last

myNumbers.firstIndex(of: 2)

myNumbers.prefix(2)

myNumbers.suffix(2)

myNumbers.dropLast(2)

myNumbers.dropFirst(2)

// algunos métodos mmutables (que cambian el valor del array)
var myNumbers2 = [45,67,89]

myNumbers2.sort { lhs, rhs in
	lhs >= rhs
}
myNumbers2.sort(by: >)

myNumbers2.removeFirst()

myNumbers2.removeLast()

myNumbers2

for value in myNumbers2 {
	value
}

myNumbers2.removeAll()

//: **Set**: colección de valores únicos, sin orden

var uniqueValues: Set<String> = ["Daniel", "Pepe", "Juan"]
uniqueValues.contains("Daniel")
uniqueValues.remove("Pepe")
uniqueValues.insert("John")
uniqueValues.insert("John")
uniqueValues.insert("John")
uniqueValues.insert("John")
uniqueValues

for randomValue in uniqueValues {
	randomValue
}

uniqueValues.removeAll()

// operaciones interesantes con sets
let setA: Set<Int> = [1,2,3]
let setB: Set<Int> = [5,2,8]
setA.intersection(setB)
setA.union(setB)

//: Dictionary: diccionarios/hash maps, colecciones de clave-valor

var levels: [String: Double] = ["Goku": 1e3, "Vegeta": 9000, "Yamcha": 0]
levels["Goku"]
levels["Frieza"]
levels.keys.contains("Goku")
levels.values.contains(0)
levels.removeValue(forKey: "Yamcha")

levels

for keyValue in levels {
	keyValue
}

for (key, value) in levels {
	key
	value
}

for key in levels.keys {
	key
}

for value in levels.values {
	value
}

levels.removeAll()

// se pueden definir de esta forma para ahorrar espacio horizontal
let otherDictionary: [String: Double] = [
	"Goku": 1e3,
	"Vegeta": 9000,
	"Yamcha": 0
]

// esta forma facilita crear diccionarios complejos como el siguiente
let object: [String: Any] = [
	"name": "Goku",
	"age": 41,
	"children": [
		[
			"name": "Goten",
			"age": 11,
			"children": [String : Any]()
		] as [String : Any],
		[
			"name": "Gohan",
			"age": 27,
			"children": [String : Any]() // ...
		]
	]
]

let dictionary1: [Int: Double] = [
	0: 132.4,
	10: 4343.23,
	7: 232
]

//: [Anterior ](@previous)
//: [ Siguiente](@next)
