//: ### Valores opcionales

var color: String = "#00FF00"
//color = nil // ¡error de compilación!, color es un String no opcional/no nullable

var colorOrNil: String? = "red"
colorOrNil = nil
colorOrNil = "blue"

// Optional Chaining: necesario poner `?` al intentar llamar propiedades o métodos
// sobre objetos opcionales.
let colorNumberOfCharactersOrNil = colorOrNil?.count
type(of: colorNumberOfCharactersOrNil)

if let colorOrNil {
	// si `colorOrNil` no es nulo...
	colorOrNil.count
} else {
	colorOrNil == nil
}

// hace un tiempo teníamos que poner if let así, ya no hace falta poner `= valor`
// siempre y cuando el nombre de la variable antes y después del = se llamen igual
if let colorOrNil = colorOrNil {
	// si `colorOrNil` no es nulo...
	colorOrNil.count
} else {
	colorOrNil == nil
}

// otra forma de comprobar si un valor es nulo es aprovechar que los opcionales son enumerados y usar un switch
// (cuando veamos los enumerados veremos en detalle esta sintaxis)
switch colorOrNil {
case Optional.some(let value):
	value
case Optional.none:
	"nil"
}

// También podemos saltarnos la comprobación de si es nulo usando `!` (force unwrap)
var someValueOrNil: String? = "hello"
type(of: someValueOrNil!)
let someValue: String = someValueOrNil!

//: [Anterior ](@previous)
//: [ Siguiente](@next)
