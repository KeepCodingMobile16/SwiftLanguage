//: ### Rangos

10...100
1..<10
...0
30...

for i in 0..<10 {
	i
}

for i in 50...63 {
	i
}

let positiveNumbersAndZero = 0...
positiveNumbersAndZero.contains(-1)
positiveNumbersAndZero.contains(1)
// a veces es mejor no conocer todos los tipos de memoria y simplemente
// dejar que Swift infiera el tipo apropiado, ya que en este caso el rango es de tipo "PartialRangeFrom<Int>"...
type(of: positiveNumbersAndZero)

let negativeNumbers = ..<0
negativeNumbers.contains(-1)
negativeNumbers.contains(1)
type(of: negativeNumbers)

Set(10...100).intersection(Set(30...40))

let numbers = [2,3,4,4,5,65,6]
numbers[0..<3]

let name = "Daniel"
name[name.index(name.startIndex, offsetBy: 0)..<name.index(name.startIndex, offsetBy: 3)]

//: Generar números aleatorios fácilmente con rangos
(1...100).randomElement()
Int.random(in: 0..<10)

//: [Anterior ](@previous)
//: [ Siguiente](@next)
