//: ### Bucles

//: `for-in`:

for i in 0..<10 {
	i
}

for i in (0..<10).reversed() {
	i
}

for i in stride(from: 10, through: 100, by: 10) {
	i
}

for i in stride(from: 10, to: 100, by: 10) {
	i
}

for i in stride(from: 2, through: 8, by: 2).reversed() {
	i
}

for number in [1,2,3] {
	number
}

//: `while`:

var inputName = "" // o: var inputName = String()
while inputName.isEmpty {
	inputName.append("2")
}
inputName

//: `repeat-while`:

repeat {
	inputName.append("-")
} while inputName.count < 10
inputName

//: [Anterior ](@previous)
//: [ Siguiente](@next)
