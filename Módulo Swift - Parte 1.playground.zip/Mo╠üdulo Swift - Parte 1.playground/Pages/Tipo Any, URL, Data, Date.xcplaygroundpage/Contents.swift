//: ### Tipo Any

var anything: Any = 10
let anythingAsInt = anything as? Int
anything = 40.5
let anythingAsDouble = anything as? Double
anything = "something"
//anything.count // aunque sepamos que en este punto anything contiene un String,
// anything sigue siendo de tipo Any, así que debemos convertirlo a String para usar sus métodos
let anythingAsString = anything as? String
anythingAsString?.count
// si estamos realmente seguros de que es un string y no queremos obtener un valor opcional al hacer un casting,
// entonces podemos usar as!
let anythingAsString2 = anything as! String
anythingAsString2.count

// Ejemplo de serialización en el que usamos Any como tipo de los valores de un diccionario

import Foundation

let jsonString: String = #"""
{
	"name": "Vegeta",
	"age": 46,
	"powerLevel": 122312.34
}
"""#
let jsonData = Data(jsonString.utf8)
let jsonObject = try? JSONSerialization.jsonObject(with: jsonData, options: []) as? [String: Any]
jsonObject
let name: Any? = jsonObject?["name"]
let nameString: String? = name as? String // "Vegeta"

//: Importante importar Foundation para algunos tipos
import Foundation

//: Ejemplo de `URL` y `Data` al hacer una petición HTTP a un servicio web.
import PlaygroundSupport
PlaygroundPage.current.needsIndefiniteExecution = true

let request = URLRequest(url: URL(string: "https://jsonplaceholder.typicode.com/todos/1")!)
let task = URLSession.shared.dataTask(with: request) { data, response, error in
	if let data {
		String(decoding: data, as: UTF8.self)
		let dictionary = try? JSONSerialization.jsonObject(with: data, options: []) as? [String: Any]
		dictionary
	}
	let httpResponse = response as? HTTPURLResponse
	httpResponse?.statusCode
	if let error {
		error
	}
}

// (Mismo ejemplo pero con async/await):
//Task {
//	do {
//		let request = URLRequest(url: URL(string: "https://jsonplaceholder.typicode.com/todos/1")!)
//		let (data, response) = try await URLSession.shared.data(for: request)
//		String(decoding: data, as: UTF8.self)
//		let httpResponse = response as? HTTPURLResponse
//		httpResponse.statusCode
//	} catch {
//		print(error)
//	}
//}

//: Ejemplo de uso de fechas en Swift con `Date` y `Calendar`.

// hoy
let rightNow = Date()
// segundos desde 1 de enero de 1970 hasta ahora
rightNow.timeIntervalSince1970
// comprobar si es hoy
Calendar.current.isDateInToday(rightNow)
// mañana
Calendar.current.date(byAdding: .day, value: 1, to: rightNow)
// ayer
Calendar.current.date(byAdding: .day, value: -1, to: rightNow)

// el inicio de hoy
Calendar.current.startOfDay(for: rightNow)
// el fin de hoy
Calendar.current.date(bySettingHour: 23, minute: 59, second: 59, of: rightNow)

// Date a String
let dateFormatter = DateFormatter()
dateFormatter.dateFormat = "dd-MM-yyyy"
let stringFromDate = dateFormatter.string(from: rightNow)

// String a Date
let dateFromString = dateFormatter.date(from: "21-05-2023")

// Crear fecha a partir de los componentes que queramos con DateComponents
let dateComponents = DateComponents(year: 2023, month: 5, day: 21)
let dateFromDateComponents = Calendar.current.date(from: dateComponents)

// Comparar fechas
dateFromString == dateFromDateComponents
// comparar con cierta granularidad (mismo day, hora, etc)
Calendar.current.compare(Date(), to: Date(), toGranularity: .day) == .orderedSame

//: [Anterior ](@previous)
