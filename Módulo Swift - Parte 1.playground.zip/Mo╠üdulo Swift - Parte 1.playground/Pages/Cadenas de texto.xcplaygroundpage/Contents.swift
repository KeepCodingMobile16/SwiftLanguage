//: ### Cadenas de texto

let text1 = ""
let text2 = String()
var text3 = String(109)

text1.count
text1.isEmpty
text3.contains("1")
text3.first
text3.last

// tenemos la gran mayoría de métodos que hemos visto con las otras colecciones, ¿por qué? porque String es una colección de Character
text3.removeLast()

for character in text3 {
	character
}

let specificText = "some day"
specificText.contains("day")

let multilineText = """
ablaba sdf
asdf
asd
fasdfasdf
asdf
 asdf asd

asdfasd
"""

// raw strings: usamos # al inicio y final de la cadena de texto
let stringWithStrangeCharacters = #"some string with "quotes" and other stuff https:\\www"#

// aquí no podríamos colocar "# dentro del string porque se confunde con la terminación
//var stringWithStrangeCharacters2 = #"very strange case: "#"#
// para esto podemos añadir más # simplemente
let stringWithStrangeCharacters2 = ##"very strange case: "#"##

//: Interpolación de strings: poder meter valores dentro de una cadena de texto
let name = "Daniel"
let age = 100.description
"My name is \(name), I'm \(100) years old."
// gracias a este método, evitamos tener que hacer lo siguiente:
"My name is " + name + ", I'm " + String(100) + " years old."

// Si en el string de abajo he tenido que convertir manualmente a String el número,
// ¿qué conversión está utilizando entonces arriba para transformar 100 en un string en la interpolación?
// los tipos `CustomStringConvertible` te obligan a declarar una propiedad `description: String`
// Int implemente el protocolo (interfaz) FixedWidthInteger que a su vez implemente BinaryInteger que a su vez implementa CustomStringConvertible

//: String format. Otra alternativa para tener 'strings parametrizados'
let stringTemplate = "%@ is %d years old"
String(format: stringTemplate, "Michael", 80)

//: Búsqueda de información en strings
let text = """
This structure uses an Array property
called items to store the
values in the stack.
"""

text.contains("Array")
if let range = text.firstRange(of: "stack") {
	text[range]
}

//: Regex: regular expressions / expresiones regulares

// método nuevo a partir de Swift 5.7 y iOS 16!
let phoneNumbers = "This is my current phone number: 666555777, but this is the old one: 999222111"
phoneNumbers.firstMatch(of: /\d{9}/)
let matches = phoneNumbers.matches(of: /\d{9}/)
for match in matches {
	match.output
}

// otra forma usando Swift con iOS anterior a Swift 5.7:
import Foundation
if let regexRange = phoneNumbers.range(of: #"\d{9}"#, options: .regularExpression) {
	phoneNumbers[regexRange]
}

let name2 = "A Ramón le gusta la gasolina."
// búsquedas en strings ignorando mayúsculas/minúsculas y tildes
if let range = name2.range(of: "ramon", options: [.caseInsensitive, .diacriticInsensitive]) {
	name2[range]
}

// otra forma usando NSRegularExpression
do {
	let regex = try NSRegularExpression(pattern: #"\d{9}"#)
	let matches = regex.matches(in: phoneNumbers, range: NSRange(location: 0, length: phoneNumbers.count))
	for match in matches {
		let nsRange = match.range
		if let swiftRange = Range(nsRange, in: phoneNumbers) {
			phoneNumbers[swiftRange]
		}
	}
} catch let error {
	print(error)
}

//: Reemplazo de texto
text.replacing("structure", with: "struct")
text.replacingOccurrences(of: "is", with: "IS")

//: [Anterior ](@previous)
//: [ Siguiente](@next)
