//: ### Conversión y verificación de tipos

let number = 56
let numberAsString = String(number)

let numberAsString2 = "123"
let numberFromString: Int? = Int(numberAsString2)

let integer: Int = 10

// En la mayoría de casos, la conversión entre valores se hace con los constructores.
Double(integer)
Float(integer)
String(integer)

String(10)

// importante también tener en cuenta que al convertir Float/Double a Int se trunca el número, eliminando la parte decimal
Int(10.2)

//: No todas las conversiones tienen sentido aunque sean válidas
// IMPORTANTE: Aquí queremos convertir un valor decimal a una cadena de texto,
// en un caso real de una app NO sería 100% correcto hacer siempre esto,
// ya que en diferentes idiomas se utilizan diferentes separadores para los decimales,
// y aquí al convertir 10.2 a un string obtenemos siempre "10.2" en vez de, por ejemplo, "10,2"
// SOLUCIÓN: NumberFormatter
String(10.2)

import Foundation

let numberFormatter = NumberFormatter()
numberFormatter.numberStyle = .decimal
numberFormatter.locale = Locale(identifier: "es_ES")
numberFormatter.string(from: NSNumber.init(value: 10.2))

// ----

// Si tenemos un tipo personalizado nuestro, convertir de un tipo al nuestro es tan sencillo como crear un constructor adecuado.
// Veremos en más detalle cómo crear nuestras estructuras de datos en la siguiente clase :)

struct MyType {

	let value: Int

	init(someInt: Int) {
		self.value = someInt
	}

	init(someDouble: Double) {
		self.value = Int(someDouble)
	}

	init(someString: String) {
		self.value = Int(someString) ?? 0
	}
}

MyType(someInt: 10)
MyType(someDouble: 10.4)
MyType(someString: "20")

// una forma sencilla de saber el tipo de una variable en tiempo de ejecución para debugear es con type(of:)

let mysteriousVariable = (1, 2.0, Character("a"), [9,9,8], [[3], [3,4]], "wtf", "🤯")
type(of: mysteriousVariable)

//: Castings con `as`
// switch nos permite comprobar tipos y hacer casting fácilmente
var anything: Any = 10
switch anything {
case let someInt as Int:
	someInt
case is Double:
	break
case let someString as String:
	someString.count
default:
	"something else"
}

// En casos de tener tipos como Any o subclases podemos usar la palabra "as"
// Podemos usarla como `as?` para intentar realizar un casting y si falla devolver un valor nulo,
// o podemos forzar a que devuelva un valor normal, aunque si fuese nulo haría crashear la app.
let anything10: Any = "something"
let anythingAsString = anything10 as? String
anythingAsString?.count
let anythingAsString2 = anything10 as! String
anythingAsString2.count

//: [Anterior ](@previous)
//: [ Siguiente](@next)
