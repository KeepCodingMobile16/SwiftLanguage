/*:
 ### Declaración de variables y constantes

 Recomendado pulsar ⌥⌘0 para abrir el panel derecho de inspector y marcar "Render Documentation".

 Tips básicos:
 - ⌥+click izquierdo sobre cualquier símbolo de Swift para + info (variables, valores, métodos, propiedades...)
 - ⌥⌘⏎ para ejecutar el playground.
 - Botón inferior ▶️ para ejecutar el playground.
 - ⇧⏎ para ejecutar playground hasta la línea actual.
 - Mantén pulsando botón inferior ▶️ para escoger entre:
	- Automatically Run: con cada cambio se vuelve a ejecutar el playgrounds.
	- Manually Run: solo se ejecuta el playground cada vez que le des al ▶️.
 - control+i para formatear documento (alinear código bien).
 - ⌘+Click para invocar menú de acciones.
 */

Bool.self

Character.self
String.self
Any.self

UInt.self
UInt8.self
UInt16.self
UInt32.self
UInt64.self

Int.self
Int8.self
Int16.self
Int32.self
Int64.self

Float16.self
Float.self
Double.self

//: Float32 y Float64 son ejemplos de aliases. Simplemente hace falta poner `typealias` seguido del alias, un `=` y por último el tipo original
// typealias Float32 = Float
Float32.self
// typealias Float64 = Double
Float64.self

typealias MyInt = UInt64

//: El tipo Decimal se encuentra en la biblioteca `Foundation`
import Foundation
Decimal.self

/*:
 Los tipos con `<TipoAquí>` son genéricos.

 Los tipos genéricos en programación son estructuras de datos reutilizables que se pueden utilizar con diferentes tipos de datos.

 Aceptan un 'type parameter' (lo que va entre < >).

 Veremos estos en más detalle más adelante cuando veamos cómo usar y crear estructuras de datos.
 */
Range<Int>.self
ClosedRange<Int>.self
Set<String>.self
Array<Int>.self
Dictionary<String, String>.self
(Int, Int, String).self
Optional<Int>.self

//: [ Siguiente](@next)

