//: ### Tuplas

let userInfo: (String, Int) = ("Daniel", 123)
userInfo.0
userInfo.1

let userInfo2: (name: String, age: Int) = ("Daniel", 123)
userInfo2.name
userInfo2.age

let userInfo3 = (name: "Daniel", age: 123)
userInfo3.name
userInfo3.age

let something: (String, Int, [Int]) = ("aa", 20, [2,3,4])
something

//: útil en funciones para devolver un par de valores
func validateString(_ string: String) -> (isValid: Bool, errorCount: Int) {
	// ...
	return (isValid: false, errorCount: 3)
}
validateString("hello!")

//: útil para intercambiar valores de variables
var a = 10
var b = 20
(b, a) = (a, b)
a
b

//: [Anterior ](@previous)
//: [ Siguiente](@next)
