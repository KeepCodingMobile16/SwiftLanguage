//: ### Declaraciones condicionales

//: if, else, else if

let vegetaPowerLevel = 10_000
let name = "Goku"

if (vegetaPowerLevel == 10000) {
	print("yes")
}

// En Swift no hace falta poner paréntesis en los condicionales, lo cuál proporciona una mejor legibilidad.
if vegetaPowerLevel == 10000 {
	print("yes")
}

if vegetaPowerLevel == 10000 { print("yes") }

// Error! En swift siempre hay que usar "{" y "}"
//if vegetaPowerLevel == 10000
//	print("yes")

// En Swift podemos usar comas para separar condiciones AND (&&), a veces se lee un poco más fácil, casi como texto escrito en vez de código.
var isTall = true
var heightInCm = 123
var tshirtColor = "red"
if isTall, heightInCm == 123, tshirtColor == "red" {
	true
}

if vegetaPowerLevel == 10 {
	print("10")
} else {
	print("not 10")
}

var place = "Earth"
if vegetaPowerLevel == 10 {
	print("10")
} else if name == "Goku" && place == "Earth" {
	print("not 10")
} else {
	print("something else")
}

//: guard

func doSomething(_ number: Int) -> Bool {
	if isEven(number) {
		if number > 100 {
			if number < 10 {
				return number == 7
			} else {
				return false
			}
		} else {
			return number == 10
		}
	} else {
		return false
	}
}

func doSomething2(_ number: Int) -> Bool {
	guard isEven(number) else { return false }
	if number > 100 {
		guard number < 10 else { return false }
		return number == 7
	} else {
		return number == 10
	}
}

func isEven(_ number: Int) -> Bool {
	return number % 2 == 0
}

//: Ternary conditional operator

vegetaPowerLevel > 9000 ? "over 9000!" : "meh"

//: switch

switch vegetaPowerLevel {
case ...0:
	print("dead")
case 1..<200:
	print("human?")
case 200..<1000:
	print("warrior")
case 1000..<100_000:
	print("super warrior")
case 100_000...:
	print("super saiyan")
default:
	break
}

switch name {
case "Goku":
	break
case "Vegeta":
	break
case "Piccolo":
	break
case _ where name.count > 10:
	break
default:
	break
}

// switch permite comprobar tipos y hacer casting también
var anything: Any = 10
switch anything {
case 0 as Int:
	break
case 0 as Double:
	break
case let someInt as Int:
	// `someInt` aquí es un entero y puedo hacer operaciones aritméticas con él
	print(someInt + 1)
case let someDouble as Double where someDouble > 0:
	print(someDouble + 100)
case is Double:
	// `anything` aquí sigue siendo Any
	print("value is double", anything)
case let someString as String:
	// `someString` aquí es un string
	print(someString.count)
case let (x, y) as (Double, Double):
	print(x, y)
default:
	print("something else")
}

//: [Anterior ](@previous)
//: [ Siguiente](@next)
