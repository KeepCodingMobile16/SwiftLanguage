//: ### Declaraciones condicionales como expresiones
// https://docs.swift.org/swift-book/documentation/the-swift-programming-language/expressions/

//: if, else, else if

let vegetaPowerLevel = 10_000

let description = if vegetaPowerLevel == 10 { "10000" } else { "not 10000" }

//: switch

let otherDescription = switch vegetaPowerLevel {
	case ...0: "dead"
	case 1..<200: "human?"
	case 200..<1000: "warrior"
	case 1000..<100_000: "super warrior"
	case 100_000...: "super saiyan"
	default: String()
}

//: [Anterior ](@previous)
//: [ Siguiente](@next)
